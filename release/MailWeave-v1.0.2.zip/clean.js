(() => {
  'use strict';
  const M = globalThis.MailWeave;
  const allowed = new Set('DIV P SPAN BR HR B STRONG I EM U S STRIKE SMALL SUB SUP UL OL LI DL DT DD BLOCKQUOTE PRE CODE TABLE THEAD TBODY TFOOT TR TH TD CAPTION A IMG H1 H2 H3 H4 H5 H6 BDI BDO'.split(' '));
  const active = new Set('SCRIPT STYLE IFRAME OBJECT EMBED SVG MATH FORM INPUT BUTTON TEXTAREA SELECT OPTION VIDEO AUDIO SOURCE LINK META BASE NOSCRIPT TEMPLATE'.split(' '));
  const blocks = 'p,div,li,pre,blockquote,table,h1,h2,h3,h4,h5,h6';
  const hasContent = node => Boolean(M.normalize(node.textContent) || node.querySelector('img, [data-mw-media], pre'));
  function remove(node, evidence, category) {
    evidence.push({ category, text: M.normalize(node.textContent).slice(0, 180), mediaCount: node.querySelectorAll('img').length });
    node.remove();
  }
  function compact(root, evidence) {
    // Bottom-up: only empty layout nodes; preserve BRs and PRE whitespace.
    for (const table of [...root.querySelectorAll('table')]) {
      if (root.contains(table) && !hasContent(table)) remove(table, evidence, 'empty-layout');
    }
    for (const n of [...root.querySelectorAll('p,div,span,li,ul,ol,table,tbody,tr,blockquote')].reverse()) {
      if (!n.closest('pre') && !hasContent(n) && !n.querySelector('td,th')) remove(n, evidence, 'empty-layout');
    }
    for (const n of [...root.querySelectorAll('hr')]) {
      if (!n.nextElementSibling || !n.previousElementSibling) remove(n, evidence, 'empty-layout');
    }
    for (const br of [...root.querySelectorAll('br')]) {
      if (!br.closest('pre') && br.previousSibling?.nodeName === 'BR' && br.previousSibling.previousSibling?.nodeName === 'BR') remove(br, evidence, 'empty-layout');
    }
  }
  function classify(root, evidence, prior) {
    for (const n of [...root.querySelectorAll('.gmail_signature, [data-smartmail="gmail_signature"], .moz-signature')]) {
      if (root.contains(n)) remove(n, evidence, 'explicit-client-signature');
    }
    // A gmail_quote class alone can wrap a new reply. Require a bounded citation.
    for (const quote of [...root.querySelectorAll('blockquote[type="cite"], blockquote')]) {
      if (!root.contains(quote)) continue;
      const attribution = quote.previousElementSibling;
      const paired = attribution?.matches('.gmail_attr, .moz-cite-prefix');
      const exact = prior.has(M.normalize(quote.textContent)) && Boolean(M.normalize(quote.textContent));
      if (quote.getAttribute('type') === 'cite' || paired || exact) {
        if (paired) remove(attribution, evidence, 'paired-attribution');
        remove(quote, evidence, exact ? 'exact-prior-in-quote' : 'bounded-client-quote');
      }
    }
    // Outlook's header node is bounded. Never truncate its following siblings.
    for (const header of [...root.querySelectorAll('#divRplyFwdMsg')]) {
      for (let sibling = header.nextElementSibling; sibling;) {
        const next = sibling.nextElementSibling;
        if (prior.has(M.normalize(sibling.textContent)) && M.normalize(sibling.textContent)) remove(sibling, evidence, 'exact-prior-in-quote');
        sibling = next;
      }
      remove(header, evidence, 'verified-reply-header');
    }
    // Flat client history: remove only whole exact prior-message nodes within
    // established client quote context, retaining unknown inline answers.
    for (const wrapper of root.querySelectorAll('.gmail_quote, .yahoo_quoted')) {
      for (const n of [...wrapper.children]) {
        if (prior.has(M.normalize(n.textContent)) && M.normalize(n.textContent)) remove(n, evidence, 'exact-prior-in-quote');
      }
    }
    compact(root, evidence);
  }
  function sanitize(root, evidence) {
    const doc = root.ownerDocument;
    function visit(node) {
      if (node.nodeType === 3) return doc.createTextNode(node.data);
      if (node.nodeType !== 1) return doc.createDocumentFragment();
      if (active.has(node.tagName)) {
        evidence.push({ category: 'unsafe-active-content', tag: node.tagName });
        return doc.createDocumentFragment();
      }
      if (node.tagName === 'IMG') {
        // No image src enters the display DOM. Even a cached Gmail URL may
        // revalidate and track a read; user activation opens the original.
        const media = doc.createElement('span');
        media.setAttribute('data-mw-media', '');
        media.setAttribute('role', 'note');
        media.textContent = `▧ ${node.getAttribute('alt') || 'Image'} — open original to view`;
        return media;
      }
      const target = allowed.has(node.tagName) ? doc.createElement(node.tagName.toLowerCase()) : doc.createDocumentFragment();
      if (target.nodeType === 1) {
        if (['ltr', 'rtl', 'auto'].includes(node.getAttribute('dir'))) target.setAttribute('dir', node.getAttribute('dir'));
        if (node.tagName === 'A') {
          try {
            const url = new URL(node.getAttribute('href'), 'https://mail.google.com/');
            if (['https:', 'http:', 'mailto:', 'tel:'].includes(url.protocol) && node.hasAttribute('href')) {
              target.setAttribute('href', url.href); target.setAttribute('target', '_blank');
              target.setAttribute('rel', 'noopener noreferrer'); target.setAttribute('referrerpolicy', 'no-referrer');
            }
          } catch { /* Keep link text, drop malformed URL. */ }
        }
        for (const attr of ['colspan', 'rowspan', 'start', 'value']) {
          const value = node.getAttribute(attr);
          if (value && /^\d{1,3}$/.test(value)) target.setAttribute(attr, value);
        }
      }
      for (const child of node.childNodes) target.append(visit(child));
      return target;
    }
    const result = doc.createElement('div');
    for (const child of root.childNodes) result.append(visit(child));
    return result;
  }
  // Logical units are complete leaf blocks or direct text runs. Containers can
  // only be removed when every substantive child belongs to the matched suffix.
  function units(root) {
    const out = [];
    function walk(node) {
      if (node.nodeType === 3) { if (M.normalize(node.data)) out.push({ node, text: M.normalize(node.data) }); return; }
      if (node.nodeType !== 1) return;
      if (node.matches('pre, table')) {
        // Preserve table cell boundaries and preformatted content in comparison.
        const text = node.tagName === 'PRE' ? node.textContent : [...node.querySelectorAll('tr')].map(r => [...r.children].map(c => M.normalize(c.textContent)).join('\t')).join('\n');
        if (M.normalize(text)) out.push({ node, text: `${node.tagName}:${text}` });
      } else if (node.matches(blocks) && !node.querySelector(blocks)) {
        if (M.normalize(node.textContent)) out.push({ node, text: M.normalize(node.textContent) });
      } else for (const child of node.childNodes) walk(child);
    }
    for (const child of root.childNodes) walk(child);
    return out;
  }
  function repeatedEndings(items) {
    const groups = new Map();
    for (const item of items) {
      if (!item.root || !item.email || item.clipped) continue;
      const list = groups.get(item.email) || []; list.push(item); groups.set(item.email, list);
    }
    for (const list of groups.values()) {
      // Reverse trie indexes exact terminal sequences. Each item stops before
      // its first unit, so whole-email repetition cannot become a blank bubble.
      const trie = { children: new Map(), members: new Set() };
      for (const item of list) item.units = units(item.root);
      // A complete contribution which is itself another message's ending is
      // potentially signature-only. Preserve that contribution in full.
      const completeEndings = new Set(), fullTrie = { children: new Map(), ends: [] };
      const prefixTrie = { children: new Map() };
      for (const item of list) {
        let cursor = fullTrie;
        for (let i = item.units.length - 1; i >= 0; i--) {
          const text = item.units[i].text;
          if (!cursor.children.has(text)) cursor.children.set(text, { children: new Map(), ends: [] });
          cursor = cursor.children.get(text);
        }
        cursor.ends.push(item);
        cursor = prefixTrie; item.prefixes = [cursor];
        for (const unit of item.units) {
          if (!cursor.children.has(unit.text)) cursor.children.set(unit.text, { children: new Map() });
          cursor = cursor.children.get(unit.text); item.prefixes.push(cursor);
        }
      }
      for (const item of list) {
        let cursor = fullTrie;
        for (let i = item.units.length - 1; i > 0; i--) {
          cursor = cursor.children.get(item.units[i].text);
          for (const match of cursor.ends) completeEndings.add(match);
        }
      }
      for (const item of list) {
        if (completeEndings.has(item)) continue;
        let cursor = trie;
        for (let i = item.units.length - 1; i > 0; i--) {
          const text = item.units[i].text;
          if (!cursor.children.has(text)) cursor.children.set(text, { children: new Map(), members: new Set() });
          cursor = cursor.children.get(text); cursor.members.add(item);
        }
      }
      const plans = new Map();
      for (const item of list) {
        if (completeEndings.has(item)) continue;
        let cursor = trie, depth = 0, matched = 0;
        for (let i = item.units.length - 1; i > 0; i--) {
          cursor = cursor.children.get(item.units[i].text); depth++;
          if (!cursor || cursor.members.size < 2) break;
          // Require a differing prefix; whole-message duplicates aren't evidence.
          const prefix = item.prefixes[item.units.length - depth];
          if ([...cursor.members].some(other => other !== item && other.prefixes[other.units.length - depth] !== prefix)) matched = depth;
        }
        if (matched) plans.set(item, item.units.slice(-matched));
      }
      for (const [item, suffix] of plans) {
        const marked = new Set(suffix.map(u => u.node));
        for (const unit of suffix) {
          let region = unit.node;
          while (region.parentElement && region.parentElement !== item.root) {
            const parent = region.parentElement;
            const inside = item.units.filter(u => parent.contains(u.node));
            if (!inside.length || inside.some(u => !marked.has(u.node))) break;
            region = parent;
          }
          if (item.root.contains(region)) remove(region.nodeType === 3 ? wrapText(region) : region, item.removals, 'exact-repeated-sender-ending');
        }
        compact(item.root, item.removals);
      }
    }
  }
  function wrapText(node) { const span = node.ownerDocument.createElement('span'); node.replaceWith(span); span.append(node); return span; }
  M.cleanOne = (record, prior = new Set()) => {
    const result = { ...record, removals: [], cleanHTML: '', state: 'unavailable' };
    if (!record.loaded) return result;
    // Template parsing is inert: source HTML never enters a live document.
    const template = document.createElement('template'); template.innerHTML = record.html || '';
    const root = document.createElement('div'); root.append(template.content);
    const originallyEmpty = !hasContent(root);
    classify(root, result.removals, prior);
    result.root = root;
    result.state = originallyEmpty ? 'empty' : hasContent(root) ? 'content' : 'removed';
    return result;
  };
  M.clean = async (records, { signal, progress = () => {} } = {}) => {
    const start = performance.now(), prior = new Set(), items = [];
    let lastYield = start;
    for (let i = 0; i < records.length; i++) {
      M.abort(signal);
      try {
        const item = M.cleanOne(records[i], prior); items.push(item);
        if (item.root) prior.add(M.normalize(item.root.textContent));
      } catch (error) { items.push({ ...records[i], state: 'error', cleanHTML: '', removals: [{ category: 'processing-error', message: String(error.message) }] }); }
      if (performance.now() - lastYield > 12) { progress(`Cleaning ${i + 1} of ${records.length} messages…`); await M.pause(0, signal); lastYield = performance.now(); }
    }
    const classified = performance.now(); repeatedEndings(items); const compared = performance.now();
    for (const item of items) {
      M.abort(signal);
      if (item.root) {
        try {
          const safe = sanitize(item.root, item.removals); compact(safe, item.removals);
          item.cleanHTML = safe.innerHTML;
          if (item.state === 'content' && !hasContent(safe)) item.state = 'removed';
        } catch (error) { item.state = 'error'; item.cleanHTML = ''; item.removals.push({ category: 'processing-error', message: String(error.message) }); }
        delete item.root; delete item.units; delete item.prefixes;
      }
      if (performance.now() - lastYield > 12) { await M.pause(0, signal); lastYield = performance.now(); }
    }
    return { items, timings: { classificationMs: classified - start, endingComparisonMs: compared - classified, sanitizeMs: performance.now() - compared } };
  };
})();
